# This file should ensure the existence of records required to run the application in every environment (production,
# development, test). The code here should be idempotent so that it can be executed at any point in every environment.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Example:
#
#   ["Action", "Comedy", "Drama", "Horror"].each do |genre_name|
#     MovieGenre.find_or_create_by!(name: genre_name)
#   end

# # Create a product Validation Test
# invalid_product = Product.create(title: "", price: nil, stock_quantity: nil)
# puts invalid_product.errors.full_messages


require 'faker'
require "csv"


# Define the path to the CSV file
csv_file = Rails.root.join('db/products.csv')
csv_data = File.read(csv_file)

# Parse the CSV file
products = CSV.parse(csv_data, headers: true, encoding: 'utf-8')

# If CSV was created by Excel in Windows you may also need to set an encoding type:
# products = CSV.parse(csv_data, headers: true, encoding: 'iso-8859-1')

# Loop through the rows of the CSV file
products.each do |row|
  # Get the category name from the CSV row
  category_name = row['category']

  # Find or create the category
  category = Category.find_or_create_by(name: category_name)

  # Create categories and products here.
  product = category.products.create(
    title: row['name'],
    price: row['price'],
    description: row['description'],
    stock_quantity: row['stock quantity']
  )

  if product.valid?
    puts "Created product: #{product.title}"
  else
    puts "Failed to create the product #{row['name']}: #{product.errors.full_messages.join(', ')}"
  end
end

# Create 676 products using Faker
676.times do
  Product.create(
    title: Faker::Commerce.product_name,
    price: Faker::Commerce.price,
    stock_quantity: Faker::Number.between(from: 1, to: 500)
  )
end

puts "Created #{Product.count} products"
puts "Created #{Category.count} categories"
