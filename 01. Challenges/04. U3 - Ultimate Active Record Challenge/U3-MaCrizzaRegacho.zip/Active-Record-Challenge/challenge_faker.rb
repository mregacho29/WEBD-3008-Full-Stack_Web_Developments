require_relative 'ar'
require 'faker'

# In the challenge_faker.rb file:
# In a loop use Faker to generate 10 new categories.
# Within this same loop use the newly created and saved category objects to
# generate 10 new products for each category.
# The name, description, price and quantity of these 10 products should
# also be generated using faker.

# Loop to generate 10 new categories
10.times do
  # Generate a new category
  category = Category.create(name: Faker::Commerce.department)

  # Loop to generate 10 new products for each category
  10.times do
    # Generate a new product using the newly created category
    product = category.products.create(
      name: Faker::Food.dish,                      # Generate a random food dish name
      description: Faker::Food.description,        # Generate a random food description
      price: Faker::Commerce.price(range: 0.5..100.0),
      stock_quantity: Faker::Number.between(from: 1, to: 100)
    )
    # Save the product to the database
    product.save
  end
end

puts 'Generated 10 new categories with 10 products each.'
