require_relative 'ar'

# Create three new products using the three different ways to create new AR objects.

# Method 1: Using new and save
product1 = Product.new

# Setting attributes individually
product1.name = "Product 1"
product1.description = "Description 1"
product1.price = 15.0
product1.stock_quantity = 10
product1.category_id = 1

# Save the product to the database
if product1.save
  puts "Product 1 saved successfully."
else
  puts "Failed to save Product 1."
end

# Print the total number of products
puts Product.count

# Method 2: Using new with attributes and save
product2 = Product.new(name: "Product 2", 
                       description: "Description 2", 
                       price: 20.0, 
                       stock_quantity: 5, 
                       category_id: 1) # this does not save the object to the DB

# Save returns a boolean
unless product2.save # this will execute the actual save/INSERT
  puts "Unable to save Product 2!"
else
  puts product2.inspect
end

# Method 3: Using create (creates and saves the object in one step)
product3 = Product.create(name: "Product 3",
                          description: "Description 3",
                          price: 25.0,
                          stock_quantity: 8,
                          category_id: 1) # Create a new object and immediately save it to the db

# Check if the product was saved successfully
if product3.save
  puts product3.inspect
else
  puts "Failed to save Product 3!"
end

# Create a Product object that is missing some required columns
invalid_product = Product.new(name: "Invalid Product")

# Attempt to save the invalid product
unless invalid_product.save
  puts "Failed to save Invalid Product!"
  # Print all the validation errors
  invalid_product.errors.full_messages.each do |message|
    puts message
  end
else
  puts invalid_product.inspect
end