require_relative 'ar'

# Find one of the products you created in challenge_create.rb and delete it from the database.

# Find the product by name
product_to_delete = Product.find_by(name: "Product 1")
# product_to_delete = Product.find_by(name: "Product 2")
# product_to_delete = Product.find_by(name: "Product 3")

# Inspect the product before deletion
puts product_to_delete.inspect

# Delete the product from the database
product_to_delete.destroy

# Confirm the deletion
puts "Deleted product: #{product_to_delete.name}"