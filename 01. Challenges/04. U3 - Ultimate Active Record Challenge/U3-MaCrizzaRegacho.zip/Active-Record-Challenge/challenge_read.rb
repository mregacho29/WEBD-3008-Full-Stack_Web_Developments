require_relative 'ar.rb'

# Use the Product class to find (any) product from the database.
product = Product.first

# Inspect the retrieved product object
puts product.inspect


# Based on the columns you find, can you determine if the products 
# table has an association with any other tables? If so, what table?
# The products table has a category_id column, 
# which indicates an association with the categories table.



# Total number of products
number_of_products = Product.count
puts "There are #{number_of_products} products in the products table."

# Names of all products above $10 with names that begin with the letter C
products_above_10_with_c = Product.where('price > ? AND name LIKE ?', 10, 'C%')
puts "Products above $10 with names that begin with 'C':"
products_above_10_with_c.each do |product|
  puts product.name
end

# Total number of products with a low stock quantity (less than 5 in stock)
low_stock_products_count = Product.where('stock_quantity < ?', 5).count
puts "Total number of products with low stock quantity: #{low_stock_products_count}"







# Find the name of the category associated with one of the products you have found.
# (You should do this without referencing the products foreign key value. Use the product's "belongs to" association instead.)
# BEVERAGE
category_name = product.category.name
puts "The category associated with the product is: #{category_name}"

# Find a specific category and use it to build and persist a new product associated with this category.
# (You should do this without manually setting the products foreign key. Look at the end of 
# this example file to see how to build an ActiveRecord object by way of an "has many" association.)
specific_category = Category.find_by(name: "Beverages")

new_product = specific_category.products.build(name: "New Beverage", 
                                              description: "A refreshing new beverage", 
                                              price: 12.0, 
                                              stock_quantity: 50)
new_product.save
puts "Created new product: #{new_product.inspect}"

# Find a specific category and then use it to locate all the 
# associated products over a certain price.
# In this case, let's use the price of $15
expensive_products = specific_category.products.where('price > ?', 15)
puts "Products in the 'Beverages' category with a price over $15:"
expensive_products.each do |product|
  puts product.name
end