require_relative 'ar'

# Find all products with a stock quantity greater than 40
products_with_high_stock = Product.where('stock_quantity > ?', 40)

# Add one to the stock quantity of each of these products and save the changes to the database
products_with_high_stock.each do |product|
  # Increment the stock quantity by 1
  product.stock_quantity += 1
  # Save the changes to the database
  product.save
end

# Print a message indicating that the stock quantities have been updated
puts "Updated stock quantities for products higher than 40"